<?php
include('CheckLogin.php');
 include('sdbcon.php'); 
 

session_start();
?>


<!DOCTYPE html>
<html>
<head>
	<title> view students recrods</title>
	<link rel="stylesheet type="text/css" href="style.css" >
	<style>
		table td{
			padding:5px 20px;
		}
	</style>
</head>
<body>
	 <div class="header">
	   <h2> Students Record</h2>
	   <h3>Student Name Here</h3>     
	   <a href="logout.php"> <button type="submit">Signout</button></a>
	 </div>
	 
  <div class="content">
  
  <?php 
  // $result = mysqli_query($db, "SELECT id,SID,Quiz,Assignment,Mid,Final FROM grade" );

  // $i=0;
  /*
 while($record = mysqli_fetch_assoc($result))
  {
	  print "---------- Record $i -----------<br />";
	  foreach ($record as $index => $field)
		  print $index." = ".$field."<br />";
	  $i++;
  } 
 
  */

  
  // $result = mysqli_query($db, "SELECT * FROM grade" );

  // $i=0;
 // $query = "SELECT * FROM product1 WHERE Product1_ID='$id' ";
  $Student_ID = $_SESSION['Username'] ;
  $query = "SELECT * FROM marks WHERE Student_ID='$Student_ID' ";
  $query_run = mysqli_query($db, $query);
   $row = mysqli_fetch_assoc($query_run);
  echo "<table class='content' > <tr><th> ID </th><th>Student ID</th><th>Quiz</th><th>Assignment</th><th>Mid Term</th><th>Final</th><th>Grade</th></tr>";
				   
 echo " <tr><th> ".$row['Marks_ID']." </th><th>".$row['Student_ID']."</th><th>".$row['Quiz_Marks']."</th><th>".$row['Assignment_Marks']."</th><th>".$row['Mid_Term_Marks']."</th><th>".$row['Final_Marks']."</th><th>".$row['Grade']."</th></tr>";

	// while($record = mysqli_fetch_assoc($result))
	// {
	// 	print "<tr>";
	// 	foreach ($record as $index => $field)

	// 		print "<td>"    .$field.   "</td>";
	// 	print "</tr>";
			
	// 	$i++;
	// }
 //   echo "</table>";
 //  mysqli_close ($db);

  ?>
   </div>
   
   
   
</body>
</html>