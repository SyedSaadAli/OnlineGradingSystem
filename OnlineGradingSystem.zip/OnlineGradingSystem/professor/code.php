<?php include('dbconfig.php'); 

if(isset($_POST['insert_btn']))
{

 $sid = $_POST['sid'];
 $quizm = $_POST['quizm'];
 $assignm = $_POST['assignm'];
 $midm = $_POST['midm'];
 $finalm = $_POST['finalm'];

$res = $quizm +$assignm +$midm +$finalm ;

if($res >= 90){
	$Grade = 'A';
}elseif($res >= 80 AND $res < 90){
	$Grade = 'B+';
}elseif($res >= 70 AND $res < 80){
	$Grade = 'B';
}elseif($res >= 60 AND $res < 70){
	$Grade = 'C+';
}elseif($res >= 50 AND $res < 60){
	$Grade = 'C';
}elseif($res >= 40 AND $res < 50){
	$Grade = 'D';
}elseif( $res < 40){
	$Grade = 'F';
}

$query3 = "SELECT * FROM student ";
    $query_run3 = mysqli_query($db, $query3);
 if(mysqli_num_rows($query_run3) > 0){
    while($row3 = mysqli_fetch_assoc($query_run3)){
        if($row3['Student_ID'] === $sid){


if($quizm <= 30 AND $assignm <= 10 AND $midm <= 20 AND $finalm <= 40){


    $query = "INSERT INTO marks (Student_ID,Quiz_Marks,Assignment_Marks,Mid_Term_Marks,Final_Marks,Grade) VALUES 
    ('$sid','$quizm','$assignm','$midm','$finalm','$Grade')";
    $query_run = mysqli_query($db, $query);
}

    if($query_run)
    {
        $_SESSION['status'] = "Student Record inserted Successfully !";
        $_SESSION['status_code'] = "success";
        header('Location: add.php'); 
    }
    else
    {
        $_SESSION['status'] = "Student Record had already inserted !";
        $_SESSION['status_code'] = "error";
        header('Location: add.php');  
    }

}else{
    header('Location: index.php');  
}
}
}

}




//--------------------------------------------------------------------------------------------------------------------------



if(isset($_POST['update_btn']))
{

 $edit_sid = $_POST['edit_sid'];
 $edit_quizm = $_POST['edit_quizm'];
 $edit_assignm = $_POST['edit_assignm'];
 $edit_midm = $_POST['edit_midm'];
 $edit_finalm = $_POST['edit_finalm'];

$res = $edit_quizm +$edit_assignm +$edit_midm +$edit_finalm ;

if($res >= 90){
    $Grade = 'A';
}elseif($res >= 80 AND $res < 90){
    $Grade = 'B+';
}elseif($res >= 70 AND $res < 80){
    $Grade = 'B';
}elseif($res >= 60 AND $res < 70){
    $Grade = 'C+';

}elseif($res >= 50 AND $res < 60){
    $Grade = 'C';
}elseif($res >= 40 AND $res < 50){
    $Grade = 'D';
}elseif( $res < 40){
    $Grade = 'F';
}

if($edit_quizm <= 30 AND $edit_assignm <= 10 AND $edit_midm <= 20 AND $edit_finalm <= 40){

    $query = "UPDATE marks SET Quiz_Marks='$edit_quizm',
    Assignment_Marks='$edit_assignm',
    Mid_Term_Marks='$edit_midm',
    Final_Marks='$edit_finalm',
    Grade='$Grade' WHERE Student_ID='$edit_sid'
    ";
    $query_run = mysqli_query($db, $query);
}

    if($query_run)
    {
        $_SESSION['status'] = "Student Record updated Successfully !";
        $_SESSION['status_code'] = "success";
        header('Location: index.php'); 
    }
    else
    {
        $_SESSION['status'] = "Student Record not updated !";
        $_SESSION['status_code'] = "error";
        header('Location: index.php');  
    }



}





//--------------------------------------------------------------------------------------------------------------------------



if(isset($_POST['delete_btn']))
{
    $id = $_POST['delete_id'];
   



    $query = "DELETE FROM marks WHERE Marks_ID='$id' ";
    $query_run = mysqli_query($db, $query);

    if($query_run)
    {
        $_SESSION['status'] = "Student Record is Deleted !";
        $_SESSION['status_code'] = "success";
        header('Location: index.php'); 
    }
    else
    {
        $_SESSION['status'] = "Student Record is NOT DELETED !";       
        $_SESSION['status_code'] = "error";
        header('Location: index.php'); 
    }    
}

?>