<?php 
include('CheckLogin.php');
include('dbconfig.php'); 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Professor 
    </title>
    <link rel="stylesheet" href="style.css">
    <style>
        .logout {
         margin-left:30%;
        }
        th,td{
            padding:10px 20px;
        }
      
    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
        <img src="images/professor.jpg" alt="">
      <a href="logout.php"> <button type="submit" value="Log Out" class="logout">Log Out</button></a> 
        <div class="btn first"><a href="index.php">View Student Record</a></div>
        <div class="btn"><a href="add.php">Add Student Record</a></div>
      
        </div>
         <?php      
         $query = "SELECT * FROM marks";
    $query_run = mysqli_query($db, $query);

                  ?>
        <div class="mainbar">
            
        <table border="1" class='content'> 
            <tr>
           
                <th>SID</th>
                <th>Quiz</th>
                <th>Assignment</th>
                <th>Mid Term</th>
                <th>Final</th>
                <th>Grade</th>
                <th>-</th>
                <th>-</th>
            </tr>
            <?php
     if(mysqli_num_rows($query_run) > 0){
                while($row = mysqli_fetch_assoc($query_run)){
                    ?>
            <tr>
                
                <td><?php  echo $row['Student_ID']; ?></td>
                <td><?php  echo $row['Quiz_Marks']; ?></td>
                <td><?php  echo $row['Assignment_Marks']; ?></td>
                <td><?php  echo $row['Mid_Term_Marks']; ?></td>
                <td><?php  echo $row['Final_Marks']; ?></td>
                <td><?php  echo $row['Grade']; ?></td>
                 <form action="edit.php" method="POST">
                <input type="hidden" name="edit_id" value="<?php echo $row['Marks_ID']; ?>">
                <td><button type="submit" name="edit_btn" class = "edit">Edit</button></td>
                   </form>
                 <form action="code.php" method="POST">
                    <input type="hidden" name="delete_id" value="<?php echo $row['Marks_ID']; ?>">
                <td><button type="submit" name="delete_btn" class = "delete">Delete</button></td>
                   </form>
            </tr>
        <?php  }} ?>
        </div>
     
    </div>
</body>
</html>