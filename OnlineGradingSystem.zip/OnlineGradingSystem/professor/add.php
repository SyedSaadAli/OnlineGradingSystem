
<?php
include('CheckLogin.php');
 include('dbconfig.php'); 
 ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Professor 
    </title>
    <link rel="stylesheet" href="style.css">
    <style>
        .logout {
         margin-left:30%;
        }
        th,td{
            padding:10px 20px;
        }
       .edit{
           margin-left:35%;
       }

    </style>
</head>
<body>
    <div class="container">
        <div class="sidebar">
           <img src="images/professor.jpg" alt="">
           <button type="submit" value="Log Out" class="logout">Log Out</button>
           <div class="btn first"><a href="index.php">View Student Record</a></div>
            <div class="btn"><a href="add.php">Add Student Record</a></div>
      
        </div>

      
     
        <div class="mainbar">
       <form action="code.php" method="POST">
       <h1 style= "text-align:centre;">Add Student Grade</h1>

        <input type="text" placeholder = "Enter Student ID" name = "sid">
        <input type="text" placeholder = "Enter Quiz Marks" name = "quizm">
        <input type="text" placeholder = "Enter Assignment Marks" name = "assignm">
        <input type="text" placeholder = "Enter Mid Term Marks" name = "midm">
        <input type="text" placeholder = "Enter Final Marks" name = "finalm">
        <button type = "submit" name="insert_btn" value = "insert" class = "edit">Insert</button>
       </form>
        </div>
    </div>
</body>
</html>